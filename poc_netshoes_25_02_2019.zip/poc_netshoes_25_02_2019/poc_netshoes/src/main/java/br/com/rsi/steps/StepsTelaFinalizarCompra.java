package br.com.rsi.steps;

import br.com.rsi.screen.TelaFinalizarCompra;
import br.com.rsinet.model.mobile.connection.open_stf.bdd.IOSBaseSteps;
import cucumber.api.java.pt.E;

public class StepsTelaFinalizarCompra extends IOSBaseSteps {
	private TelaFinalizarCompra telaFinalizarCompra = new TelaFinalizarCompra(getDriver(), getRelatorio(), null);
	
	@E("^clico na tela Finalizar Compra no botao Boleto Bancario$")
	public void clico_na_tela_Finalizar_Compra_no_botao_Boleto_Bancario() throws Throwable {
	    telaFinalizarCompra.clicarBtnBoletoBancario();
	}

	@E("^clico na tela Finalizar Compra no botao Finalizar Pedido$")
	public void clico_na_tela_Finalizar_Compra_no_botao_Finalizar_Pedido() throws Throwable {
	    telaFinalizarCompra.clicarFinalizarPedido();
	}
	
	@Override
	public void setupPages() {
		
	}
}