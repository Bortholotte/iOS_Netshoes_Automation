package br.com.rsi.screen;

import static org.junit.Assert.assertTrue;

import java.util.Map;

import org.openqa.selenium.By;

import br.com.rsinet.model.mobile.ios.iOSScreen;
import br.com.rsinet.util.RelatorioEvidencias;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;

public class TelaProduto extends iOSScreen{

	public TelaProduto(IOSDriver<IOSElement> driver, RelatorioEvidencias relatorio, Map<String, String> massa) {
		super(driver, relatorio, massa);
	}
	
	private IOSElement btnProximo() {
		return getDriver().findElement(By.xpath("//*[contains(@name,'Tamanho') or contains(@name,'tamanho')] "));
	}
	
	private IOSElement btnComprar() {
		return getDriver().findElement(By.name("uibutton.addToCartButton"));
	}
	
	private IOSElement btnTamanho(String tamanhoProduto) {
		return getDriver().findElement(By.name(tamanhoProduto));
	}
	
	private IOSElement btnIrParaOCarrinho() {
		return getDriver().findElement(By.name("UIAlertController.alertButton.0"));
	}
	
	public void clicarBtnProximo(){
		int count = 0;
		boolean displayed = false;
		while (count < 5 && !displayed) {
			try {
				if(btnProximo().isDisplayed()) {
					btnProximo().click();
					displayed = true;
				}
			} catch (Exception e) {
				waitSeconds(1);
				count++;
			}
		}
		assertTrue("Texto tamanho n�o encontrado.", displayed);
	}
	
	public void clicarBtnComprar() {
		btnComprar().click();
	}
	
	public void clicarBtnTamanho(String tamanhoProduto) {
		btnTamanho(tamanhoProduto).click();
	}
	
	public void clicarBtnIrParaOCarrinho() {
		int count = 0;
		boolean displayed = false;
		while (count < 5 && !displayed) {
			try {
				if(btnIrParaOCarrinho().isDisplayed()) {
					btnIrParaOCarrinho().click();
					displayed = true;
				}
			} catch (Exception e) {
				waitSeconds(1);
				count++;
			}
		}
		assertTrue("Botao Ir para o carrinho n�o encontrado.", displayed);
	}
	
	@Override
	protected void setUpScreenElements(Map<String, String> arg0) {	
	}

	@Override
	protected void setScreenName() {
		this.screenName = getClass().getSimpleName();
	}

}
