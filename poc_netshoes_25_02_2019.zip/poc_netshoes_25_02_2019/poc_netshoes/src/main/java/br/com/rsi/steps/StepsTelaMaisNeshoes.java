package br.com.rsi.steps;

import br.com.rsi.screen.TelaMaisNetshoes;
import br.com.rsinet.model.mobile.connection.open_stf.bdd.IOSBaseSteps;
import cucumber.api.java.After;
import cucumber.api.java.pt.E;

public class StepsTelaMaisNeshoes extends IOSBaseSteps{
	private TelaMaisNetshoes telaMaisNetshoes = new TelaMaisNetshoes(getDriver(), getRelatorio(), null);

	@E("^valido na tela Mais Netshoes se estou logado$")
	public void valido_na_tela_Mais_Neshoes_se_estou_deslogado() throws Throwable {
		telaMaisNetshoes.validarLogado();
	}

	@E("^valido na tela Mais Netshoes se estou deslogado$")
	public void valido_na_tela_Mais_Netshoes_se_estou_deslogado() throws Throwable {
		telaMaisNetshoes.validarDesolgado();
	}
	
	@E("^clico na tela Mais Netshoes no botao Entrar$")
	public void clico_na_tela_Mais_Netshoes_no_botao_Entrar() throws Throwable {
		telaMaisNetshoes.clicarBtnLoginLogout();
	}
	
	@E("^clico na tela Mais Netshoes no botao Sair$")
	public void clico_na_tela_Mais_Netshoes_no_botao_Sair() throws Throwable {
		telaMaisNetshoes.clicarBtnLoginLogout();
	}
	
	@After
	public void quit() {
		telaMaisNetshoes.quit();
	}
	
	@Override
	public void setupPages() {
		
	}
}