package br.com.rsi.steps;

import br.com.rsi.screen.TelaObrigadoPorComprar;
import br.com.rsinet.model.mobile.connection.open_stf.bdd.IOSBaseSteps;
import cucumber.api.java.pt.E;

public class StepsTelaObrigadoPorComprar extends IOSBaseSteps {
	private TelaObrigadoPorComprar telaObrigadoPorComprar = new TelaObrigadoPorComprar(getDriver(), getRelatorio(), null);
	
	@E("^clico na tela Obrigado por Comprar no botao Agora nao$")
	public void clico_na_tela_Obrigado_por_Comprar_no_botao_Agora_nao() throws Throwable {
		telaObrigadoPorComprar.clicarBtnAgoraNao();
	}

	@E("^valido na tela Obrigado por Comprar o Boleto$")
	public void valido_na_tela_Obrigado_por_Comprar_o_Boleto() throws Throwable {
		telaObrigadoPorComprar.validarBoletoBancario();
	}
	
	@Override
	public void setupPages() {
		
	}
}