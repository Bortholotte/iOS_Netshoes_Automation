package br.com.rsi.steps;

import br.com.rsi.screen.TelaCarrinho;
import br.com.rsinet.model.mobile.connection.open_stf.bdd.IOSBaseSteps;
import cucumber.api.java.pt.E;

public class StepsTelaCarrinho extends IOSBaseSteps {
	TelaCarrinho telaCarrinho = new TelaCarrinho(getDriver(), getRelatorio(), null);
	
	@E("^clico na tela Carrinho no botao Continuar$")
	public void clico_na_tela_Carrinho_no_botao_Continuar() throws Throwable {
	    telaCarrinho.clicarBtnContinuar();
	}
	
	@Override
	public void setupPages() {
		
	}
}