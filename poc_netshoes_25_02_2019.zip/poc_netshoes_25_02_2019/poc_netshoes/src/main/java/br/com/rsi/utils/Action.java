package br.com.rsi.utils;

import static org.junit.Assert.assertTrue;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.MultiTouchAction;
import io.appium.java_client.TouchAction;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class Action {
	private WebDriver driver;
	WebDriverWait wait;
	TouchAction<?> t;
	MultiTouchAction mta;

	public Action(IOSDriver<IOSElement> driver) {
		this.driver = driver;
		t = new TouchAction<>(driver);
		mta = new MultiTouchAction(driver);
		wait = new WebDriverWait(driver, 20);
	}

	public Action(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 20);
	}

	public TouchAction<?> swipe(int startx, int starty, int endx, int endy, int duration) {
		Duration d = Duration.ofMillis(duration);
		new PointOption<>().withCoordinates(startx, starty);

		t = t.press(PointOption.point(startx, starty)).waitAction(new WaitOptions().withDuration(d))
				.moveTo(PointOption.point(endx, endy)).release();
		return t;
	}
	
	public TouchAction<?> swipeDirection(int pixels, int duration, Direcao direcition) {
		Dimension d = this.driver.manage().window().getSize();
		int diagonal = (int) Math.sqrt(((d.height - 1) * (d.height - 1)) + ((d.width - 1) * (d.width - 1)));
		int startY = 0;
		int startX = 0;
		int endY = 0;
		int endX = 0;
		//System.out.println(
		//		"Dimens�es da tela:\nAltura: " + d.height + "\nLargura: " + d.width + "\nDiagonal:" + diagonal);
		switch (direcition) {
		case CIMA:
			if (pixels > d.height) {
				pixels = d.height - 2;
			}
			return swipe(d.width / 2, (d.height / 2) + (pixels / 2), d.width / 2, (d.height / 2) - (pixels / 2),
					duration);
		case BAIXO:
			if (pixels > d.height) {
				pixels = d.height - 2;
			}
			return swipe(d.width / 2, (d.height / 2) - (pixels / 2), d.width / 2, (d.height / 2) + (pixels / 2),
					duration);
		case DIAGONAL_INFERIOR_DIREITA:
			if (pixels > diagonal) {
				pixels = diagonal - 2;
			}
			startX = (d.width / 2) - ((d.width * pixels / diagonal) / 2);
			startY = (d.height / 2) - ((d.height * pixels / diagonal) / 2);
			endX = (d.width / 2) + ((d.width * pixels / diagonal) / 2);
			endY = (d.height / 2) + ((d.height * pixels / diagonal) / 2);

			return swipe(startX, startY, endX, endY, duration);
		case DIAGONAL_INFERIOR_ESQUERDA:
			if (pixels > diagonal) {
				pixels = diagonal - 2;
			}
			startX = (d.width / 2) + ((d.width * pixels / diagonal) / 2);
			startY = (d.height / 2) - ((d.height * pixels / diagonal) / 2);
			endX = (d.width / 2) - ((d.width * pixels / diagonal) / 2);
			endY = (d.height / 2) + ((d.height * pixels / diagonal) / 2);

			return swipe(startX, startY, endX, endY, duration);

		case DIAGONAL_SUPERIOR_DIREITA:
			if (pixels > diagonal) {
				pixels = diagonal - 2;
			}
			startX = (d.width / 2) - ((d.width * pixels / diagonal) / 2);
			startY = (d.height / 2) + ((d.height * pixels / diagonal) / 2);
			endX = (d.width / 2) + ((d.width * pixels / diagonal) / 2);
			endY = (d.height / 2) - ((d.height * pixels / diagonal) / 2);

			return swipe(startX, startY, endX, endY, duration);
		case DIAGONAL_SUPERIOR_ESQUERDA:
			if (pixels > diagonal) {
				pixels = diagonal - 2;
			}

			startX = (d.width / 2) + ((d.width * pixels / diagonal) / 2);
			startY = (d.height / 2) + ((d.height * pixels / diagonal) / 2);
			endX = (d.width / 2) - ((d.width * pixels / diagonal) / 2);
			endY = (d.height / 2) - ((d.height * pixels / diagonal) / 2);

			return swipe(startX, startY, endX, endY, duration);
		case DIREITA:
			if (pixels > d.width) {
				pixels = d.width - 2;
			}
			return swipe((d.width / 2) - (pixels / 2), (d.height / 2), (d.width / 2) + (pixels / 2), (d.height / 2),
					duration);
		case ESQUERDA:
			if (pixels > d.width) {
				pixels = d.width - 2;
			}
			return swipe((d.width / 2) + (pixels / 2), (d.height / 2), (d.width / 2) - (pixels / 2), (d.height / 2),
					duration);
		}
		return t;
	}

	public void moveToElement(WebDriver driver, By element) {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.findElement(element));
	}

	public void waitElementHide(WebDriver driver, int seconds, By element) {
		wait = new WebDriverWait(driver, seconds);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(element));
	}

	public void esperaModal(WebDriver driver, int seconds) {
		waitElementHide(driver, seconds, By.id("ui-datepicker-div"));
	}

	@SuppressWarnings("unchecked")
	public void longPress(WebElement element, int duration) {
		Duration d = Duration.ofMillis(duration);
		int startx = element.getLocation().x;
		int starty = element.getLocation().y;
		t = new TouchAction<>((IOSDriver<IOSElement>) driver).press(PointOption.point(startx, starty))
				.waitAction(new WaitOptions().withDuration(d)).release();
		t.perform();
	}

	public String dateFormat(Date data, String formato) {
		SimpleDateFormat sdf = new SimpleDateFormat(formato);
		return sdf.format(data);
	}
	
	public void zoom(boolean zoomIn) {
		Dimension d = this.driver.manage().window().getSize();

		if (zoomIn) {
			TouchAction<?> t1 = swipe(0, 0, (d.width / 2) + 100, (d.height / 2) + 100, 1000);
			TouchAction<?> t2 = swipe(0, 0, (d.width / 2) - 100, (d.height / 2) - 100, 1000);
			mta.add(t1).add(t2).perform();

		} else {
			TouchAction<?> t1 = swipe((d.width / 2) + 100, (d.height / 2) + 100, 0, 0, 1000);
			TouchAction<?> t2 = swipe((d.width / 2) + 100, (d.height / 2) + 100, 0, 0, 1000);
			mta.add(t1).add(t2).perform();
		}

	}

	public WebElement waitElementa(By element, int tempo) throws InterruptedException {
		try {
			return driver.findElement(element);
		} catch (Exception e) {
			if (tempo > 0) {
				waitElementa(element, tempo--);
			}
			Thread.sleep(1000);
		}
		return null;
	}

	public IOSElement moveToIOSElement(By element, int tentativas) {
		IOSElement elemento = (IOSElement) wait.until(ExpectedConditions.elementToBeClickable(element));
//		driver.getPageSource();
		Duration d = Duration.ofMillis(500);

		while (tentativas > 0) {
			if (elemento.getLocation().y >= driver.manage().window().getSize().height - 5) {
				tentativas--;
				swipeDirection(500, 1000, Direcao.CIMA)
						.press(new PointOption<>().withCoordinates(driver.manage().window().getSize().getWidth() / 2,
								250 + (driver.manage().window().getSize().getHeight() / 2)))
						.waitAction(new WaitOptions().withDuration(d)).release().perform();
//				driver.getPageSource();
			} else {
//				driver.getPageSource();
				break;
			}
		}
//		driver.getPageSource();
		return elemento.getLocation().y >= driver.manage().window().getSize().height - 5 ? elemento : null;
	}
	
	public void moveToIOSElement(By element, int tentativas, Direcao direction) {
		IOSElement elemento = driver.findElement(element);
		int y;
		int count = 0;
		int windowHight = driver.manage().window().getSize().getHeight();
		boolean elementFound = false;
		while(count < tentativas && !elementFound) {
			y = elemento.getLocation().getY() + (elemento.getSize().getHeight());
			if(y > windowHight) {
				swipeDirection((windowHight/2), 1000, direction).perform();
				count++;
			} else {
				elementFound = true;
				break;
			}
		}
		assertTrue(elementFound);
	}
}