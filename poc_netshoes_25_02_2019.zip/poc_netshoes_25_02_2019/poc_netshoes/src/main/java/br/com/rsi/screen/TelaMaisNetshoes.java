package br.com.rsi.screen;

import static org.junit.Assert.assertTrue;

import java.util.Map;

import org.openqa.selenium.By;

import br.com.rsinet.model.mobile.ios.iOSScreen;
import br.com.rsinet.util.RelatorioEvidencias;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;

public class TelaMaisNetshoes extends iOSScreen {

	public TelaMaisNetshoes(IOSDriver<IOSElement> driver, RelatorioEvidencias relatorio, Map<String, String> massa) {
		super(driver, relatorio, massa);
	}

	private IOSElement btnLoginLogout() {
		return getDriver().findElement(By.name("loginLogout"));
	}
	
	private IOSElement txtNomeUsuario() {
		return getDriver().findElement(By.name("Ol� Claudio"));
	}
	
	private IOSElement txtVisitante() {
		return getDriver().findElement(By.name("Ol� visitante!"));
	}
	
	private IOSElement validaBtnEntrar() {
		return getDriver().findElement(By.xpath("//*[@label='Entrar']"));
	}
	
	private IOSElement validaBtnSair() {
		return getDriver().findElement(By.xpath("//*[@label='Sair']"));
	}
	
	public void validarLogado() {
		int count = 0;
		boolean displayed = false;
		while (count < 5 && !displayed) {
			try {
				if(validaBtnSair().isDisplayed())
					displayed = true;
			} catch (Exception e) {
				waitSeconds(1);
				count++;
			}
		}
		if(displayed) {
			assertTrue(validaBtnSair().isDisplayed());
			assertTrue(txtNomeUsuario().isDisplayed());			
		} else {
			assertTrue("Bot�o sair n�o foi encontrado.", displayed);
		}
	}
	
	public void validarDesolgado() {
		assertTrue(txtVisitante().isDisplayed());
	}
	
	public void clicarBtnLoginLogout() {
		btnLoginLogout().click();
	}
	
	@Override
	protected void setUpScreenElements(Map<String, String> arg0) {
	}
	
	@Override
	protected void setScreenName() {
		this.screenName = getClass().getSimpleName();
	}

	public void quit() {
		getDriver().closeApp();
	}
}
