package br.com.rsi.screen;

import static org.junit.Assert.assertTrue;

import java.util.Map;

import org.openqa.selenium.By;

import br.com.rsinet.model.mobile.ios.iOSScreen;
import br.com.rsinet.util.RelatorioEvidencias;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;

public class TelaEntrar extends iOSScreen{

	public TelaEntrar(IOSDriver<IOSElement> driver, RelatorioEvidencias relatorio, Map<String, String> massa) {
		super(driver, relatorio, massa);
	}

	public IOSElement logarComEmail() {
		return getDriver().findElement(By.name("QUERO LOGAR COM MEU E-MAIL OU CPF"));
	}
	
	public IOSElement campoEmail() {
		return getDriver().findElement(By.name("Digite seu email, CPF ou CNPJ"));
	}
	
	public IOSElement campoSenha() {
		return getDriver().findElement(By.name("Senha"));
	}
	
	public IOSElement btnEntrar() {
		return getDriver().findElement(By.name("ENTRAR"));
	}
	
	public void clicarBtnLogarComEmail() {
		logarComEmail().click();
	}
	
	public void clicarBtnEntrar() {
		btnEntrar().click();
	}
	
	public void digitarCampoEmail(String email) {
		int count = 0;
		boolean displayed = false;
		while (count < 5 && !displayed) {
			if(campoEmail().isDisplayed()) {
				campoEmail().sendKeys(email);
				displayed = true;
			} else {
				waitSeconds(1);
				count++;
			}
		}
		assertTrue("Campo Email n�o encontrado.", displayed);
	}
	
	public void digitarCampoSenha(String senha) {
		campoSenha().sendKeys(senha);
	}
	
	@Override
	protected void setUpScreenElements(Map<String, String> arg0) {	
	}
	
	@Override
	protected void setScreenName() {
		this.screenName = getClass().getSimpleName();
	}
}
