package br.com.rsi.screen;

import static org.junit.Assert.assertTrue;

import java.util.Map;

import org.openqa.selenium.By;

import br.com.rsinet.model.mobile.ios.iOSScreen;
import br.com.rsinet.util.RelatorioEvidencias;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;

public class TelaInicial extends iOSScreen{

	public TelaInicial(IOSDriver<IOSElement> driver, RelatorioEvidencias relatorio, Map<String, String> massa) {
		super(driver, relatorio, massa);
		
	}

	private IOSElement txtNetshoes() {
		return getDriver().findElement(By.name("Netshoes.HomeTableView"));
	}
	
	private IOSElement btnMais() {
		return getDriver().findElement(By.name("UITabBar.More"));
	}
	
	private IOSElement btnBuscar() {
		return getDriver().findElement(By.name("UITabBar.Search"));
	}
	
	public void validarTelaInicial() {
		int count = 0;
		boolean displayed = false;
		while (count < 5 && !displayed) {
			if(txtNetshoes().isDisplayed()) {
				assertTrue(txtNetshoes().isDisplayed());
				displayed = true;
			} else {
				waitSeconds(1);
				count++;
			}
		}
		assertTrue("Falha na valida��o da tela Inicial", displayed);
	}
	
	public void clicarBtnMais() {
		btnMais().click();
	}
	
	public void clicarBtnBuscar() {
		btnBuscar().click();
	}
	
	@Override
	protected void setUpScreenElements(Map<String, String> arg0) {
	}
	
	@Override
	protected void setScreenName() {
		this.screenName = this.getClass().getSimpleName();
	}
}