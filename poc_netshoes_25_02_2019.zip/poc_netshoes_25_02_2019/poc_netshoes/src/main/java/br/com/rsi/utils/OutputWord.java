package br.com.rsi.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;

public class OutputWord {
	XWPFDocument doc = new XWPFDocument();
	FileOutputStream file;
	String path;

	public OutputWord(String caminho) {
		/*
		 * File f = new File(System.getProperty("user.dir") + "\\screenshot\\" +
		 * caminho); f.mkdirs();
		 */
		path = caminho + "\\evidencia.docx";
		// file = new FileOutputStream(new
		// File(System.getProperty("user.dir")+"\\screenshot\\"+caminho+"\\evidencia.docx"));

	}

	public void addStep(String filename, String desc) throws IOException, InvalidFormatException {
		XWPFParagraph paragrafo = doc.createParagraph();
		XWPFRun run = paragrafo.createRun();

		this.file = new FileOutputStream(new File(path));
		run.setText(desc);

		doc.write(file);
		this.file.close();

		File imagem = new File(filename);
		
		FileInputStream f = new FileInputStream(imagem);
		run.addBreak();
		run.addPicture(f, XWPFDocument.PICTURE_TYPE_JPEG, imagem.getName(), Units.toEMU(244), Units.toEMU(500));
		f.close();
		this.file = new FileOutputStream(new File(path));
		doc.write(file);

	}

}
