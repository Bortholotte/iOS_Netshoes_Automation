package br.com.rsi.screen;

import static org.junit.Assert.assertTrue;

import java.util.Map;

import org.openqa.selenium.By;

import br.com.rsinet.model.mobile.ios.iOSScreen;
import br.com.rsinet.util.RelatorioEvidencias;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;

public class TelaObrigadoPorComprar extends iOSScreen {

	public TelaObrigadoPorComprar(IOSDriver<IOSElement> driver, RelatorioEvidencias relatorio, Map<String, String> massa) {
		super(driver, relatorio, massa);
	}
	
	private IOSElement btnAgoraNao() {
		return getDriver().findElement(By.name("Agora N�o"));
	}
	
	private IOSElement txtBoletoBancario(){
		return getDriver().findElement(By.xpath("//*[@value='C�DIGO BOLETO:']"));
	}

	public void clicarBtnAgoraNao() {
		int count = 0;
		boolean displayed = false;
		while (count < 3 && !displayed) {
			try {
				if(btnAgoraNao().isDisplayed()) {
					btnAgoraNao().click();
					displayed = true;
				}
			} catch (Exception e) {
				waitSeconds(1);
				count++;
			}
		}
	}
	
	public void validarBoletoBancario() {
		assertTrue(txtBoletoBancario().isDisplayed());
	}
	
	@Override
	protected void setUpScreenElements(Map<String, String> arg0) {
	}

	@Override
	protected void setScreenName() {
		this.screenName = getClass().getSimpleName();
	}
}