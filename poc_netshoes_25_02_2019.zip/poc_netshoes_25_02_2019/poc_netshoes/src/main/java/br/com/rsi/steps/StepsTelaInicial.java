package br.com.rsi.steps;

import br.com.rsi.screen.TelaInicial;
import br.com.rsinet.model.mobile.connection.open_stf.bdd.IOSBaseSteps;
import cucumber.api.java.pt.Dado;
import cucumber.api.java.pt.E;

public class StepsTelaInicial extends IOSBaseSteps{
	private TelaInicial telaInicial = new TelaInicial(getDriver(), getRelatorio(), null);
	
	@Dado("^que estou na tela inicial$")
	public void que_estou_na_tela_inicial() throws Throwable {
		telaInicial.validarTelaInicial();
	}

	@E("^clico na tela Incial no botao Mais$")
	public void clico_na_tela_Incial_no_botao_Mais() throws Throwable {
		telaInicial.clicarBtnMais();
	}
	
	@E("^clico na tela Inicial no botao Buscar$")
	public void clico_na_tela_Inicial_no_botao_Buscar() throws Throwable {
	    telaInicial.clicarBtnBuscar();
	}
	
	@Override
	public void setupPages() {
		
	}
}