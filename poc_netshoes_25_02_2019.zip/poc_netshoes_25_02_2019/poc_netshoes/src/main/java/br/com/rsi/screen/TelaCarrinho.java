package br.com.rsi.screen;

import static org.junit.Assert.assertTrue;

import java.util.Map;

import org.openqa.selenium.By;

import br.com.rsinet.model.mobile.ios.iOSScreen;
import br.com.rsinet.util.RelatorioEvidencias;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;

public class TelaCarrinho extends iOSScreen{

	public TelaCarrinho(IOSDriver<IOSElement> driver, RelatorioEvidencias relatorio, Map<String, String> massa) {
		super(driver, relatorio, massa);
	}
	
	private IOSElement btnContinuar() {
		return getDriver().findElement(By.name("CONTINUAR"));
	}

	public void clicarBtnContinuar() {
		int count = 0;
		boolean displayed = false;
		while (count < 5 && !displayed) {
			try {
				if(btnContinuar().isDisplayed()) {
					btnContinuar().click();
					displayed = true;
				}
			} catch (Exception e) {
				waitSeconds(1);
				count++;
			}
		}
		assertTrue("Botao Continuar n�o encontrado.", displayed);
	}
	
	@Override
	protected void setUpScreenElements(Map<String, String> arg0) {
	}

	@Override
	protected void setScreenName() {
		this.screenName = getClass().getSimpleName();
	}

}
