package br.com.rsi.steps;

import br.com.rsi.screen.TelaProduto;
import br.com.rsinet.model.mobile.connection.open_stf.bdd.IOSBaseSteps;
import cucumber.api.java.pt.E;

public class StepsTelaProduto extends IOSBaseSteps{
	TelaProduto telaProduto = new TelaProduto(getDriver(), getRelatorio(), null);
	
	@E("^clico na tela Produto no botao Proximo$")
	public void clico_na_tela_Produto_no_botao_Comprar() throws Throwable {
	    telaProduto.clicarBtnProximo();
	}
	
	@E("^clico na tela Produto no botao Comprar produto$")
	public void clico_na_tela_Produto_no_botao_Comprar_produto() throws Throwable {
	    telaProduto.clicarBtnComprar();
	}

	@E("^clico na tela Produto no botao Ir para o carrinho$")
	public void clico_na_tela_Produto_no_botao_Ir_para_o_carrinho() throws Throwable {
	    telaProduto.clicarBtnIrParaOCarrinho();
	}
	
	@E("^clico na tela Produto no botao '(.*)'$")
	public void clico_na_tela_Produto_no_botao_tamanho(String tamanhoProduto) throws Throwable {
		telaProduto.clicarBtnTamanho(tamanhoProduto);
	}
	
	@Override
	public void setupPages() {
		
	}
}