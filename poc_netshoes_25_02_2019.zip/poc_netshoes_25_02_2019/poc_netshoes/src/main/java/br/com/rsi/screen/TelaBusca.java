package br.com.rsi.screen;

import static org.junit.Assert.assertTrue;

import java.time.Duration;
import java.util.Map;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import br.com.rsi.utils.Action;
import br.com.rsi.utils.Direcao;
import br.com.rsinet.model.mobile.ios.iOSScreen;
import br.com.rsinet.util.RelatorioEvidencias;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;

public class TelaBusca extends iOSScreen {
	private Action action;
	private Wait<IOSDriver<IOSElement>> fluentWait;
	
	public TelaBusca(IOSDriver<IOSElement> driver, RelatorioEvidencias relatorio, Map<String, String> massa) {
		super(driver, relatorio, massa);
		action = new Action(driver);
		fluentWait = new FluentWait<IOSDriver<IOSElement>>(driver).withTimeout(Duration.ofSeconds(10)).pollingEvery(Duration.ofSeconds(1)).ignoring(NoSuchElementException.class);
	}

	private  IOSElement campoBusca() {
		return getDriver().findElement(By.name("Buscar por"));
	}
	
	public void digitarCampoBusca(String pesquisa) {
		campoBusca().sendKeys(pesquisa);
		campoBusca().sendKeys(Keys.ENTER);
	}
	
	public void clicarBtnProduto(String nomeProduto) {
		int count = 0;
		boolean elementFound = false;
		int alturaTela = getDriver().manage().window().getSize().getHeight();
		while(count < 10 && !elementFound) {
			try {
				if(getDriver().findElement(By.xpath("(//*[contains(@value,'" + nomeProduto + "')])[1]/..")).isDisplayed())
					getDriver().findElement(By.xpath("(//*[contains(@value,'" + nomeProduto + "')])[1]/..")).click();
				elementFound = true;
			} catch (Exception e) {
				action.swipeDirection(alturaTela/2, 1000, Direcao.CIMA).perform();
				count++;
			}
		}
	}
	
	@Override
	protected void setUpScreenElements(Map<String, String> arg0) {
	}

	@Override
	protected void setScreenName() {
		this.screenName = getClass().getSimpleName();
	}
}