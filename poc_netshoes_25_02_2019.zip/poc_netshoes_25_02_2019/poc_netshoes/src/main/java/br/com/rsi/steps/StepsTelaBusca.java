package br.com.rsi.steps;

import br.com.rsi.screen.TelaBusca;
import br.com.rsinet.model.mobile.connection.open_stf.bdd.IOSBaseSteps;
import cucumber.api.java.pt.E;

public class StepsTelaBusca extends IOSBaseSteps {
	private TelaBusca telaBusca = new TelaBusca(getDriver(), getRelatorio(), null);
	
	@E("^digito na tela Busca no campo Buscar por '(.*)'$")
	public void digito_na_tela_Busca_no_campo_Buscar_por(String pesquisa) throws Throwable {
		telaBusca.digitarCampoBusca(pesquisa);
	}
	
	@E("^clico na tela Busca no botao Produto '(.*)'$")
	public void clico_na_tela_Busca_no_botao_Produto(String nomeProduto) throws Throwable {
		telaBusca.clicarBtnProduto(nomeProduto);
	}
	
	@Override
	public void setupPages() {
		
	}
}