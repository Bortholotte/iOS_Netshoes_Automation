package br.com.rsi.main;

import java.util.logging.Logger;

import br.com.rsinet.execution.ExecutionMode;
import br.com.rsinet.main.ParametersHandler;

public class Main {

	private static Logger LOG = Logger.getLogger(Main.class.getName());

	public static void main(String[] args) {
		new ParametersHandler().handle(ExecutionMode.MOBILE_CENTER);
	}
}