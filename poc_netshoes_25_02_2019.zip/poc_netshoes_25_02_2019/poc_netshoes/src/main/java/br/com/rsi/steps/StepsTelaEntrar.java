package br.com.rsi.steps;

import br.com.rsi.screen.TelaEntrar;
import br.com.rsinet.model.mobile.connection.open_stf.bdd.IOSBaseSteps;
import cucumber.api.java.pt.E;

public class StepsTelaEntrar extends IOSBaseSteps {
	private TelaEntrar telaEntrar = new TelaEntrar(getDriver(), getRelatorio(), null);
	
	@E("^clico na tela Entrar no botao Quero logar com meu email$")
	public void clico_na_tela_Entrar_no_botao_Quero_logar_com_meu_email() throws Throwable {
		telaEntrar.clicarBtnLogarComEmail();
	}

	@E("^digito na tela Entrar no campo Digite seu email o valor '(.*)'$")
	public void digito_na_tela_Entrar_no_campo_Digite_seu_email_o_valor_claudiogomes_hotmail_com(String email) throws Throwable {
		telaEntrar.digitarCampoEmail(email);
	}

	@E("^digito na tela Entrar no campo Senha o valor '(.*)'$")
	public void digito_na_tela_Entrar_no_campo_Senha_o_valor_Senha(String senha) throws Throwable {
		telaEntrar.digitarCampoSenha(senha);
	}

	@E("^clico na tela Entrar no botao Entrar$")
	public void clico_na_tela_Entrar_no_botao_Entrar() throws Throwable {
		telaEntrar.clicarBtnEntrar();
	}
	
	@Override
	public void setupPages() {
		
	}
}