package br.com.rsi.screen;

import static org.junit.Assert.assertTrue;

import java.util.Map;

import org.openqa.selenium.By;

import br.com.rsi.utils.Action;
import br.com.rsi.utils.Direcao;
import br.com.rsinet.model.mobile.ios.iOSScreen;
import br.com.rsinet.util.RelatorioEvidencias;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;

public class TelaFinalizarCompra extends iOSScreen {
	private Action action;
	
	public TelaFinalizarCompra(IOSDriver<IOSElement> driver, RelatorioEvidencias relatorio, Map<String, String> massa) {
		super(driver, relatorio, massa);
		action = new Action(driver);
	}
	
	private IOSElement btnBoletoBancario() {
		return getDriver().findElement(By.xpath("//*[@value='Boleto banc�rio']"));
	}
	
	private IOSElement btnFinalizarPedido() {
		return getDriver().findElement(By.name("Checkout.Resumo.footerview.buttonFinalizar pedido"));
	}
	
	private IOSElement txtFormaDePagameto() {
		return getDriver().findElement(By.name("FORMA DE PAGAMENTO"));
	}	

	public void clicarBtnBoletoBancario() {
		boolean achou = false;
		int count = 0;
		while(count < 5) {
			try {
				if(txtFormaDePagameto().isEnabled()) {
					achou = true;
					break;
				}
			} catch (Exception e) {
				waitSeconds(1);
				count++;
			}
		}
		rsiAssert.assertTrue(achou);
		action.moveToIOSElement(By.xpath("//*[@value='Boleto banc�rio']"), 2, Direcao.CIMA);
		btnBoletoBancario().click();
	}
	
	public void clicarFinalizarPedido() {
		int count = 0;
		boolean elementFound = false;
		while(count < 10 && !elementFound) {
			try {
				btnFinalizarPedido().click();
				elementFound = true;
			} catch (Exception e) {
				action.swipeDirection(getDriver().manage().window().getSize().getHeight()/2, 1000, Direcao.CIMA).perform();
				count++;
			}
		}
	}
	
	@Override
	protected void setUpScreenElements(Map<String, String> arg0) {
	}

	@Override
	protected void setScreenName() {
		this.screenName = getClass().getSimpleName();
	}
}